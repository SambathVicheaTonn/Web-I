var hourNow = new Date().getHours();
var greeting="";
var customername = "Chaky";
var products = [
    "Pizza",
    "Naan",
    "Sourdough",
    "Foccacia",
    "iPhone X",
];
var price = [40, 10, 20, 80, 1000];
var percent = 0.75;
var productsText = "";
var productsElement = document.getElementById("product-list");
var totalPrice = price[0]+price[1]+price[2]+price[3]+price[4];
var discountPrice=percent*totalPrice;
 for(var i = 0; i < 5; i++){
            productsText += "<li class='list-group-item'>" +products[i] + "<span class='badge'>$" +price[i] + "</li>";
        }
if (hourNow >= 18) {
    greeting= "Good evening";
   } else if (hourNow >= 12) { 
    greeting = "Good afternoon";
   }else if (hourNow > 5){ 
    greeting = "Good morning";
   }

productsElement.innerHTML = productsText;


document.getElementById("greeting").innerHTML = greeting;
document.getElementById("customer-name").innerHTML = "Chaky";
document.getElementById("price").innerHTML = "$" + discountPrice + "  " + "<span class='badge alert-danger'>25% off";


